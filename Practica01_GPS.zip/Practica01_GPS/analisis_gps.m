clc; 
clear; 
close all;

escenarios = ["interior","aire_libre","entre_edificios"];
R = 6371000;   % Radio de la Tierra (m)

for k = 1:length(escenarios)

    fprintf('\n=== Escenario: %s ===\n', escenarios(k));

    %% --- Cargar datos del modulo (CSV) ---
    gps = readtable(fullfile(escenarios(k), "gps_modulo.csv"));

    % Ajusta si tus columnas tienen otros nombres
    latGPS = gps.latitud;
    lonGPS = gps.longitud;
    altGPS = gps.altitud_m;

    %% --- Cargar datos del celular (MAT) ---
    load(fullfile(escenarios(k), "gps_celular.mat"));

    % Variables tipicas de MATLAB Mobile
    latCel = Position.Latitude;
    lonCel = Position.Longitude;
    altCel = Position.Altitude;

    %% --- Igualar longitudes ---
    n = min([length(latGPS), length(latCel)]);
    latGPS = latGPS(1:n); lonGPS = lonGPS(1:n);
    latCel = latCel(1:n); lonCel = lonCel(1:n);

    %% --- Trayectoria ---
    figure
    plot(lonCel, latCel, 'b.-')
    hold on
    plot(lonGPS, latGPS, 'r.-')
    title(['Trayectoria - ' char(escenarios(k))])
    legend('Celular','Modulo GPS')
    xlabel('Longitud')
    ylabel('Latitud')
    grid on

    %% --- Error (Haversine) ---
    lat1 = deg2rad(latCel);
    lon1 = deg2rad(lonCel);
    lat2 = deg2rad(latGPS);
    lon2 = deg2rad(lonGPS);

    a = sin((lat2-lat1)/2).^2 + cos(lat1).*cos(lat2).*sin((lon2-lon1)/2).^2;
    c = 2*atan2(sqrt(a), sqrt(1-a));
    error_m = R * c;

    fprintf('Error promedio: %.2f m\n', mean(error_m));
    fprintf('Desviacion estandar: %.2f m\n', std(error_m));

    %% --- Grafica del error ---
    figure
    plot(error_m)
    title(['Error - ' char(escenarios(k))])
    xlabel('Muestras')
    ylabel('Error (m)')
    grid on
end

